<?php

class koneksi
{

	public $koneksi;

	function __construct()
	{
		$this->koneksi = mysqli_connect("localhost", "root", "", "praujikom_thoriq");
		if (mysqli_connect_errno()) {
			echo "Koneksi gagal";
		}
		// 	}else {
		//        echo "Koneksi berhasil";
		//    }
	}
	function get_user($username, $password)
	{
		$data = $this->koneksi->query("select * from user where username='$username' and password='$password'");
		return $data;
	}
	function get_pengguna()
	{

		$data = $this->koneksi->query("select * from user");
		return $data;
	}

	function add_pengguna($id_user, $nama_lengkap, $alamat, $tlp, $email, $tgl_daftar, $username, $password)
	{
		$this->koneksi->query("insert into user values('$id_user','$nama_lengkap','$alamat','$tlp','$email','$tgl_daftar','$username','$password')");
		return true;
	}

	function get_penggunaById($id_user)
	{
		$data = $this->koneksi->query("select * from user where id_user='$id_user'");
		return $data;
	}

	function update_pengguna($id_user, $nama_lengkap, $alamat, $tlp, $email, $tgl_daftar, $username, $password)
	{

		$this->koneksi->query("UPDATE user set nama_lengkap='$nama_lengkap',alamat='$alamat',tlp='$tlp',email='$email', tgl_daftar='$tgl_daftar', username='$username',password='$password' where id_user='$id_user'");
		return true;
	}
	function delete_pengguna($id_user)
	{
		$this->koneksi->query("delete from user where id_user='$id_user'");
		return true;
	}
	function add_barang($kode_barang, $nama_barang, $jenis_barang, $harga_beli, $harga_jual)
	{
		$this->koneksi->query("insert into barang values('$kode_barang','$nama_barang','$jenis_barang','$harga_beli','$harga_jual')");
		return true;
	}
	function get_barangById($kode_barang)
	{
		$data = $this->koneksi->query("SELECT * FROM barang where kode_barang ='$kode_barang'");
		return $data;
	}
	function get_barang()
	{
		$data = $this->koneksi->query("SELECT *FROM barang");
		return $data;
	}
}
$data = new koneksi();
