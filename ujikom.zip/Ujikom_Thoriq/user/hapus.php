<?php
include '../koneksi.php';

$id_user = $_GET['id_user'];

if ($data->delete_pengguna($id_user)) {
    echo "<script> 
            alert('Data berhasil dihapus!');
            document.location.href = 'index.php';
        </script>
    ";
}
